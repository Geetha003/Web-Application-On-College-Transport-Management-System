<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Marking</title>
    <style>
           body {
            background-image: url('background.jpeg');
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }
        td{
            background-color: white;
        }
        th {
            background-color: #D9D9D9;
        }
    </style>
</head>
<body>
<div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
            <li><a href="adminHomePage.php" style="text-decoration: none">Home</a></li>
            <li><a href="notification.php" style="text-decoration: none">Notification</a></li>
            <li><a href="addbus.php" style="text-decoration: none">Feedback</a></li>
            <li><a href="profile.html" style="text-decoration: none">Profile</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
        </ul>
    </div>
    <h2 style="text-align: center;">Attendance</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Student Name</th>
                <th>Status (Absent)</th>
            </tr>
        </thead>
        <tbody>
            <!-- Sample data, you can dynamically generate rows using a backend language like PHP or JavaScript -->
            <tr>
                <td>1</td>
                <td>John Doe</td>
                <td><input type="checkbox"></td>
            </tr>
            <tr>
                <td>2</td>
                <td>Jane Smith</td>
                <td><input type="checkbox"></td>
            </tr>
            <tr>
                <td>1</td>
                <td>John Doe</td>
                <td><input type="checkbox"></td>
            </tr>
            <tr>
                <td>2</td>
                <td>Jane Smith</td>
                <td><input type="checkbox"></td>
            </tr>
            <!-- Add more rows as needed -->
        </tbody>
    </table>
</body>
</html>
