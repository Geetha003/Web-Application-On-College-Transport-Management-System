<?php
// Include your database connection file
include 'db_conn.php';
session_start();

// Fetch the user_id from the session (assuming you have stored it during login)
$user_id = $_SESSION['user_id'];

// Fetch the available amount from the database
$query = "SELECT amountAvailable FROM transporter_signup WHERE user_Id = '$user_id'";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalAmountAvailable = $row['amountAvailable'];
} else {
    // Default value if user not found or amount not available
    $totalAmountAvailable = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <title>Add Cash Page</title>
    <style>
        /* Your styles go here */
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 20px;
        }

        #addCashHeader {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        #amountContainer {
            margin-bottom: 20px;
        }

        #amountLabel {
            display: flex;
            margin-bottom: 5px;
            margin-left: 20px;
        }

        #amountInput {
            padding: 8px;
            width: 96%;
        }

        #addCashButton {
            padding: 10px;
            font-size: 16px;
            cursor: pointer;
            width: 97.5%;
            background-color: grey;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
            margin-bottom:20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        #addCashButton {
            padding: 10px;
    font-size: 18px;
    font-weight: bold; /* Add this line to make the text bold */
    cursor: pointer;
    width: 97.5%;
    background-color: grey;
    color: white;
    border: none; /* Remove the outline by setting the border to none */
    outline: none;
        }
        #balanceContainer {
            margin-top: 20px;
            font-size: 18px;
        }

    </style>
</head>
<body>

<div class="navbar">
    <!-- Your navigation bar goes here -->
    <div class="logo">
      <img src="buslogo.png" alt="Transportzz Logo">
      <h1>Transportzz</h1>
  </div>
  <ul class="nav-links">
  <li><a href="daystuHomePage.php" style="text-decoration: none">Home</a></li>
      <li><a href="payment2.php" style="text-decoration: none">Single Pay</a></li>
 
      <li><a href="notification2.php" style="text-decoration: none">Notification</a></li>
      <li><a href="feedback2.php" style="text-decoration: none">Feedback</a></li>
      <li><a href="profile3.php" style="text-decoration: none">Profile</a></li>
      <li><a href="changepassword2.php" style="text-decoration: none">change password</a></li>
      <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>

    <br>

<!-- <div id="addCashHeader">Add Cash</div> -->
<br>
</div>
<div id="balanceContainer">
        Total Amount Available: <span id="totalAmountAvailable"><?php echo $totalAmountAvailable; ?></span>
    </div>
<div id="amountContainer">
    <label for="amountInput" id="amountLabel">Amount:<br></label>
    <input type="number" id="amountInput" placeholder="Enter amount" />
</div>

<!-- Single "Add Cash" button -->
<button id="addCashButton" class="buy_now">Add Cash</button>

<script>
    $('body').on('click', '.buy_now', function (e) {
        var totalAmount = $('#amountInput').val();
        var product_id = $(this).attr("data-id");
        var options = {
            "key": "rzp_test_H2UTYFN9YkS4xf",
            "amount": (totalAmount * 100),
            "name": "Payment Amount",
            "description": "Payment",
            "image": "yellow.png",
            "handler": function (response) {
                $.ajax({
                    url: 'payment-proccess.php',
                    type: 'post',
                    dataType: 'json',
                    data: {
                        razorpay_payment_id: response.razorpay_payment_id,
                        totalAmount: totalAmount,
                        product_id: product_id,
                    },
                    success: function (msg) {
                        window.location.href = 'https://www.tutsmake.com/Demos/php/razorpay/success.php';
                    }
                });
            },
            "theme": {
                "color": "#FFC805"
            }
        };
        var rzp = new Razorpay(options);
        rzp.open();
        e.preventDefault();
    });
</script>
</body>
</html>
