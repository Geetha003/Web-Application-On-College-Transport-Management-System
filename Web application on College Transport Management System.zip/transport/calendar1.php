<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendar</title>
    <style>
        /* Add your CSS styles for the calendar here */
        .calendar {
            font-family: Arial, sans-serif;
            text-align: center;
        }
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            width: 30px;
        }
        th {
            background-color: #f0f0f0;
        }
        .current-day {
            background-color: #ffcccb; /* Highlight color for the current day */
        }
    </style>
</head>
<body>
    <div class="calendar">
        <h2>Calendar</h2>
        <table>
            <thead>
                <tr>
                    <th>Sun</th>
                    <th>Mon</th>
                    <th>Tue</th>
                    <th>Wed</th>
                    <th>Thu</th>
                    <th>Fri</th>
                    <th>Sat</th>
                </tr>
            </thead>
            <tbody>
                <!-- JavaScript will add calendar days here -->
            </tbody>
        </table>
    </div>

    <script>
    function createCalendar() {
        const currentDate = new Date();
        const currentMonth = currentDate.toLocaleString('default', { month: 'long' });
        const currentYear = currentDate.getFullYear();
        const currentDay = currentDate.getDate();
        const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
        const firstDayIndex = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
        const daysElement = document.querySelector('tbody');
        let dayCount = 1;

        // Set the text content of the h2 tag to display the current month and year
        document.querySelector('h2').textContent = `${currentMonth} ${currentYear}`;

        for (let i = 0; i < 6; i++) {
            const row = document.createElement('tr');
            for (let j = 0; j < 7; j++) {
                const cell = document.createElement('td');
                if ((i === 0 && j < firstDayIndex) || dayCount > daysInMonth) {
                    // Empty cell before the first day and after the last day
                    cell.textContent = '';
                } else {
                    cell.textContent = dayCount;
                    if (dayCount === currentDay) {
                        cell.classList.add('current-day');
                    }
                    dayCount++;
                }
                row.appendChild(cell);
            }
            daysElement.appendChild(row);
        }
    }

    createCalendar();
</script>
</body>
</html>




