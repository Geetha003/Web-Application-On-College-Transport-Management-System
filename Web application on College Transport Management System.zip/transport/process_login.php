<?php

require_once('db_conn.php');
session_start(); // Start a session

$email = $_POST['userId'];
$pass = $_POST['pass'];

$sql = "SELECT * FROM `transporter_signup` WHERE user_Id = '$email' AND password = '$pass'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {
    // User is successfully logged in
    $row = mysqli_fetch_assoc($result); // Fetch the user's data
    $user_id = $row['user_Id']; // Extract user_id from the result

    // Store user_id in a session variable
    $_SESSION['user_id'] = $user_id;
    if (strpos($user_id, "ad") === 0) {
    // User ID starts with "ad"
    header("Location: adminHomePage.php");
    exit();
} elseif (strpos($user_id, "bi") === 0) {
    // User ID starts with "f"
    header("Location: inchargeHomePage.php");
    exit();
} elseif (strpos($user_id, "st") === 0) {
    // User ID starts with "st"
    header("Location: studentHomePage.php");
    exit();
} elseif (strpos($user_id, "sd") === 0) {
    // User ID starts with "st"
    header("Location: daystuHomePage.php");
    exit();
}elseif (strpos($user_id, "f") === 0) {
    // User ID starts with "st"
    header("Location: studentHomePage.php");
    exit();
} else {
    // Handle cases where the prefix doesn't match any of the expected values
    // You can redirect to an error page or do something else
    echo "Invalid user ID.";
}
} else {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Invalid Email or Password')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}

?>