<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Realtime location tracker</title>

    <!-- leaflet css -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />

    <style>
        body {
            margin: 0;
            padding: 0;
        }

        #map {
            width: 100%;
            height: 100vh;
        }
    </style>
</head>

<body>
    <div id="map"></div>

    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script>
        // Initialize the map centered on user's location
        var map = L.map('map').setView([0, 0], 15);

        // OSM layer
        var osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        });
        osm.addTo(map);

        // User's location tracking
        if (!navigator.geolocation) {
            console.log("Your browser doesn't support geolocation feature!")
        } else {
            navigator.geolocation.getCurrentPosition(getPosition);

            // Update user's location when it changes
            navigator.geolocation.watchPosition(updateUserPosition);
        }

        var userMarker, circle;

        function getPosition(position) {
            var lat = position.coords.latitude
            var long = position.coords.longitude
            var accuracy = position.coords.accuracy

            if (!userMarker) {
                userMarker = L.marker([lat, long], { icon: L.divIcon({ className: 'user-icon' }) }).addTo(map);
                circle = L.circle([lat, long], { radius: accuracy }).addTo(map);
            } else {
                userMarker.setLatLng([lat, long]);
                circle.setLatLng([lat, long]);
                circle.setRadius(accuracy);
            }

            console.log("Your coordinate is: Lat: " + lat + " Long: " + long + " Accuracy: " + accuracy);
        }

        function updateUserPosition(position) {
            var lat = position.coords.latitude
            var long = position.coords.longitude
            var accuracy = position.coords.accuracy

            userMarker.setLatLng([lat, long]);
            circle.setLatLng([lat, long]);
            circle.setRadius(accuracy);
        }

        // Bus data
        var busData = [
            {
                id: 1,
                name: "Bus 1",
                latitude: 14.0860746,
                longitude: 100.608406,
                accuracy: 10,
            },
            {
                id: 2,
                name: "Bus 2",
                latitude: 13.7563,
                longitude: 100.5018,
                accuracy: 15,
            },
            // Add more bus data as needed
        ];

        // Bus markers
        var busMarkers = [];

        // Create markers for each bus
        busData.forEach(function (bus) {
            var marker = L.marker([bus.latitude, bus.longitude]).bindPopup(bus.name);
            busMarkers.push(marker);
            marker.addTo(map);
        });

        // Update bus locations
        function updateBusLocations() {
            busData.forEach(function (bus) {
                // Simulated movement (replace with actual data)
                bus.latitude += (Math.random() - 0.5) * 0.01;
                bus.longitude += (Math.random() - 0.5) * 0.01;
                bus.accuracy = 10;

                // Update the marker's position
                var marker = busMarkers.find(function (m) {
                    return m.getLatLng().lat === bus.latitude && m.getLatLng().lng === bus.longitude;
                });

                if (marker) {
                    marker.setLatLng([bus.latitude, bus.longitude]);
                }
            });
        }

        // Start updating bus locations
        setInterval(updateBusLocations, 5000); // Update every 5 seconds

    </script>
    <style>
        /* Style for the user's location marker */
        .user-icon {
            width: 20px;
            height: 20px;
            background-color: blue;
            border-radius: 50%;
        }
    </style>
</body>

</html>
