<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #FFD74A;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-container {
            background-color: white;
            border-radius: 10px solid yellow;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 33%;
            text-align: center;
        }

        .login-header {
            font-size: 30px;
            font-weight: bold;
            color: #FFC805;
            margin-bottom: 20px;
        }

        label {
            display: inline-block;
            text-align: left;
            width: 50%;
            box-sizing: border-box;
            margin-left: 20px;
        }

        .input-field {
            width: 50%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            margin-right: 20px;
        }

        .submit-button {
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px; /* Added margin for spacing */
        }

        /* Additional styles for horizontal alignment */
        .form-element-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .form-element-container label {
            width: auto;
            margin-right: 10px;
        }

        .form-element-container .input-field {
            width: 70%; /* Adjust as needed */
        }

        .signup-link {
            margin-top: 20px; /* Added margin for spacing */
            text-align: center;
        }

        .signup-link a {
            text-decoration: none;
            color: blue;
        }
    </style>
    <title>Login Page</title>
</head>
<body>

<div class="login-container">
    <div class="login-header">Login</div>
    <form method="POST" action="adminlogin.php">

        <!-- Container for User ID -->
        <div class="form-element-container">
            <label for="userId">User ID</label>
            <input type="text" id="userId" name="userId" class="input-field" placeholder="User ID" required>
        </div>

        <!-- Container for Password -->
        <div class="form-element-container">
            <label for="pass">Password</label>
            <input type="password" id="pass" name="pass" class="input-field" placeholder="Password" required>
        </div>

        <button type="submit" class="submit-button">Submit</button>

        <div class="signup-link">
            <p>or <a href="transport_signup.php">Sign up</a></p>
        </div>
    </form>
</div>
</body>
</html>
