<?php
// Include the database connection file
include 'db_conn.php';

session_start();

// Fetch user_id based on the session
$user_id = $_SESSION['user_id'];

// Initialize variables for bus_id and student_id
$bus_id = '';
$student_id = '';

// Query to retrieve bus_id based on user_id from bus_details
$sql_get_bus_id = "SELECT bus_id FROM bus_details WHERE busInChargeID = '$user_id'";
$result_get_bus_id = $conn->query($sql_get_bus_id);

if ($result_get_bus_id) {
    $row_bus = $result_get_bus_id->fetch_assoc();
    $bus_id = $row_bus['bus_id'];

    // Query to retrieve student_id based on bus_id from bus_requests
    $sql_get_student_id = "SELECT student_id FROM bus_requests WHERE busId = '$bus_id'";
    $result_get_student_id = $conn->query($sql_get_student_id);

    if ($result_get_student_id) {
        $row_student = $result_get_student_id->fetch_assoc();
        $student_id = $row_student['student_id'];

        // Use the student_id to retrieve student details from transporter_signup
        $sql_student_details = "SELECT * FROM transporter_signup WHERE user_Id = '$student_id' and user_Id LIKE 'st%'";
        $result = $conn->query($sql_student_details);

        $counter = 1;
    } else {
        echo "Error fetching student_id: " . $conn->error;
    }
} else {
    echo "Error fetching bus_id: " . $conn->error;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transportzz Dashboard</title>
    <style>
        body {
            background-image: url('background.jpeg');
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
            border: 1px solid #ddd;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        td{
            background-color: white;
        }
        th {
            background-color: #D9D9D9;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
            <li><a href="inchargeHomePage.php" style="text-decoration: none">Home</a></li>
            <li><a href="receivenotification.php" style="text-decoration: none">Notification</a></li>
            <li><a href="feedback.php" style="text-decoration: none">Feedback</a></li>
            <li><a href="profile.php" style="text-decoration: none">Profile</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
        </ul>
    </div>
    <h2 style="text-align: center;"> Student Details </h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Blood Group</th>
                <th>Contact Number</th>
                <th>Address</th>
            </tr>
        </thead>
        <tbody>
        <?php
            if ($result) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $counter . "</td>";
                    echo "<td>" . $row["Name"] . "</td>";
                    echo "<td>" . $row["blood_group"] . "</td>";
                    echo "<td>" . $row["contact_no"] . "</td>";
                    echo "<td>" . $row["Address"] . "</td>";
                    echo "</tr>";
                    $counter++;
                }
            } else {
                echo "Error fetching student details: " . $conn->error;
            }
            ?>
            <!-- Add more rows as needed -->
        </tbody>
    </table>
        

</body>
</html>



