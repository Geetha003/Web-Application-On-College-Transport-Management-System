<?php
// Include your database connection file
include 'db_conn.php';

if (isset($_POST['action']) && isset($_POST['request_id'])) {
    $action = $_POST['action'];
    $request_id = $_POST['request_id'];

    // Update the status in the database based on the action
    $status = ($action === 'accept') ? 'Accepted' : 'Rejected';
    $update_sql = "UPDATE day_request SET status = '$status' WHERE id = '$request_id'";
    $conn->query($update_sql);

    // Redirect back to the previous page
    header("Location: inchargeHomePage.php");
    exit;
} else {
    // Handle invalid or missing data
    echo 'Invalid request.';
}
?>
