<?php
// Include the database connection file
include 'db_conn.php';
// Assuming you have a database connection established
session_start();
// Fetch blood group and contact number based on the user_id
$userId = $_SESSION['user_id']; // Assuming you have stored the user_id in a session variable

$query = "SELECT blood_group, contact_no FROM transporter_signup WHERE user_Id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $userId);
$stmt->execute();
$stmt->bind_result($bloodGroup, $contactNumber);
$stmt->fetch();
$stmt->close();
// Fetch boarding point based on the user_id
// Assuming you have the user_id in a session variable
$userId = $_SESSION['user_id'];

// Fetch bus_id from bus_requests
$query = "SELECT busId FROM bus_requests WHERE student_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $userId);
$stmt->execute();
$stmt->bind_result($busId);
$stmt->fetch();
$stmt->close();

// Fetch boarding point (route) based on the bus_id
$query = "SELECT routes FROM bus_details WHERE bus_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $busId);
$stmt->execute();
$stmt->bind_result($boardingPoint);
$stmt->fetch();
$stmt->close();

// Fetch "Valid Up To" from the bus_requests table
$query = "SELECT `date` FROM bus_requests WHERE student_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $userId);
$stmt->execute();
$stmt->bind_result($date);
$stmt->fetch();
$stmt->close();
if (!empty($date)) {
    $date = date_create($date); // Convert the date string to a DateTime object
    date_add($date, date_interval_create_from_date_string('1 year')); // Increase the year by 1
    $validUpTo = date_format($date, 'Y-m-d'); // Format the date back to "year-month-date"
} else {
    $validUpTo = "No Date Found"; // Handle the case where no date is found
}
?>
<?php
// Check if the success query parameter is set
if (isset($_GET['success']) && $_GET['success'] == 1) {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Request submitted successfully')
    window.location.href='studentHomePage.php';
    </SCRIPT>");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transportzz Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
            margin-bottom:20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px;
        }
        .container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3); /* Box shadow added */
            border-radius: 10px; /* Rounded corners for the box */
            width:25%;
            margin-left:550px;
            background:white;
        }

        /* Style for the left side (details) */
        .left-side {
            flex: 1;
            padding: 5px;
        }

        /* Style for the right side (profile image) */
        .right-side {
            flex: 1;
            padding: 5px;
            text-align: center;
        }

        /* Style for the image */
        .profile-image {
            max-width: 40%;
            height: auto;
            border-radius: 100%;
            margin-right:200px;
        }  
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px;
        }
        .dashboard-item {
            background-color: white;
            border-radius: 10px;
            padding: 15px;
            margin: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            min-width: 80%;
        }
        .dashboard-item img {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        } 
        .rectangle-container {
            background-color: blue; /* Background color set to blue */
            color: white; /* Text color set to white */
            padding: 10px 20px; /* Padding for the content */
            border-radius: 5px; /* Rounded corners for the rectangle */
            display: inline-block; /* Inline-block to contain the text */
            width:24%;
            text-align:center;
            margin-left:548px;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Style for the dropdown content */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            padding: 12px 16px;
            display: block;
            text-align: left;
        }

        /* Style for the dropdown items on hover */
        .dropdown-content a:hover {
            background-color: #ddd;
        }

        /* Show the dropdown content when hovering over the dropdown container */
        .dropdown:hover .dropdown-content {
            display: block;
        }
 


    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
            <li><a href="studentHomePage.php" style="text-decoration: none">Home</a></li>
            <li class="dropdown">
                <span style="color:#6C06BC">Payment</span>
                <div class="dropdown-content">
                    <a href="payment1.php" style="text-decoration: none">Single Pay</a>
                    <a href="payment.php" style="text-decoration: none">Annual Pay</a>
                </div>
            </li>
       
            <li><a href="notification1.php" style="text-decoration: none">Notification</a></li>
            <li><a href="feedback.php" style="text-decoration: none">Feedback</a></li>
            <li><a href="profile.php" style="text-decoration: none">Profile</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
        </ul>
    </div>
    <div class="rectangle-container">
        Bus Pass
    </div>
    <div class="container">
        <!-- Left side with profile details -->
        <div class="left-side">
            <ul>
                <li><strong>Boarding Point:</strong><?php echo htmlspecialchars($boardingPoint); ?></li>
                <li><strong>Blood Group:</strong><?php echo htmlspecialchars($bloodGroup); ?></li>
                <li><strong>Contact Number:</strong><?php echo htmlspecialchars($contactNumber); ?></li>
                <li><strong>Valid Up To:</strong><?php echo htmlspecialchars($validUpTo); ?></li> <!-- Display the calculated "Valid Up To" value here -->
            </ul>
        </div>
        
        <!-- Right side with the profile image -->
        <div class="right-side">
            <img class="profile-image" src="student.png" alt="Profile Image">
        </div>
    </div>
    <div class="dashboard">
        <div class="dashboard-item">
            <img src="trackbus.png" alt="track bus">
            <p><a href="" style="text-decoration: none">Track Bus</a></p>
        </div>
        <div class="dashboard-item">
            <img src="attcalendar.png" alt="attendance report">
            <p><a href="calendar.php" style="text-decoration: none">Calender</a></p>
        </div>
        <div class="dashboard-item">
            <img src="requestbus.jpg" alt="request bus">
            <p><a href="bus_search.php" style="text-decoration: none">Request Bus</a></p>
        </div>
        <div class="dashboard-item">
            <img src="orange.png" alt="request bus">
            <p><a href="bus_search1.php" style="text-decoration: none">Per-Day Bus Request</a></p>
        </div>
        <div class="dashboard-item">
            <img src="buspass.png" alt="request bus">
            <p><a href="daybuspass.php" style="text-decoration: none">Per-Day Bus Pass</a></p>
        </div>
    </div>
</body>
</html>