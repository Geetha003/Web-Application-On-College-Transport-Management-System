<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            background-color:#FFD74A;
        }

        #content {
            text-align: center;
            margin-bottom: 20px;
        }

        #image {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }

        #startButton {
            


            background-color: #FFECA8 ;
    color: black;
    padding: 10px 20px;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    font-size: 20px;
    width: 65%
        }
        
    </style>
    <title>Your Web Page</title>
</head>
<body>

    <div id="content">
        <h1>Transportzz</h1>
        <br>
        <img src="yellow.png" width="200" height="200"; >
        <br>
        <br>
        <br>
        <a href="users.php"><button id="startButton">Start</button></a>
    </div>

</body>
</html>
