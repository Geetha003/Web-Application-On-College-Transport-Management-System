<?php
// Include your database connection file
include 'db_conn.php';

// Start the session (assuming you've already logged in)
session_start();
// Assuming a successful login
if (!isset($_SESSION['user_id'])) {
    // Redirect to the login page if the user is not logged in
    header("Location: loginhtml.php");
    exit();
}
$user_id = $_POST['userId']; // Replace with the actual user ID
$_SESSION['user_id'] = $user_id; // Set the user ID in a session variable


// Check if the user is logged in

// Retrieve the user's profile data from the database
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE user_id = '$user_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = $row['name'];
    $blood_group = $row['blood_group'];
    $contact_no = $row['contact_no'];
    $address = $row['address'];
    $image_path = $row['image_path']; // Path to the user's profile image
} else {
    // Handle the case where the user's profile is not found
    echo "User profile not found.";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Profile</title>
</head>
<body>
    <h1>User Profile</h1>
    <img src="<?php echo $image_path; ?>" alt="User Image" width="150" height="150">
    <p><strong>Name:</strong> <?php echo $name; ?></p>
    <p><strong>User ID:</strong> <?php echo $user_id; ?></p>
    <p><strong>Blood Group:</strong> <?php echo $blood_group; ?></p>
    <p><strong>Contact Number:</strong> <?php echo $contact_no; ?></p>
    <p><strong>Address:</strong> <?php echo $address; ?></p>
    <!-- Add more profile fields as needed -->

    <!-- Add links or buttons for editing or updating the profile -->
</body>
</html>


