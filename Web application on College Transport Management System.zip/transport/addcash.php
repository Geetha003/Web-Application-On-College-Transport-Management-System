<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Cash Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 20px;
        }

        #addCashHeader {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        #amountContainer {
            margin-bottom: 20px;
        }

        #amountLabel {
            display: flex;
            margin-bottom: 5px;
            margin-left: 20px;
        }

        #amountInput {
            padding: 8px;
            width: 96%;
        }

        #addCashButton {
            padding: 10px;
            font-size: 16px;
            cursor: pointer;
            width: 97.5%;
            background-color: grey;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
            margin-bottom:20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
    </style>
</head>
<body>
<div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
            <li><a href="studentHomePage.php" style="text-decoration: none">Home</a></li>
            <!-- <li class="dropdown">
                <span style="color:#6C06BC">Payment</span>
                <div class="dropdown-content">
                    <a href="payment1.php" style="text-decoration: none">Single Pay</a>
                    <a href="payment.php" style="text-decoration: none">Annual Pay</a>
                </div>
            </li> -->
            <li> <a href="payment.php" style="text-decoration: none">Annual Pay</a></li>
            <li><a href="notification1.php" style="text-decoration: none">Notification</a></li>
            <li><a href="feedback1.php" style="text-decoration: none">Feedback</a></li>
            <li><a href="profile2.php" style="text-decoration: none">Profile</a></li>
            <li><a href="changepassword1.php" style="text-decoration: none">change password</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
        </ul>
    </div>
    <div id="addCashHeader">Add Cash</div>
    
    <div id="amountContainer">
        <label for="amountInput" id="amountLabel">Amount :<br></label>
        <input type="number" id="amountInput" placeholder="Enter amount" />
    </div>

    <button id="addCashButton" onclick="addCash()">Add Cash</button>

    <script>
        function addCash() {
            // You can add your logic here to handle the 'Add Cash' button click
            // For example, you can retrieve the amount entered by the user using:
            var amount = document.getElementById('amountInput').value;
            
            // Perform actions with the amount (e.g., send to server, update balance, etc.)
            // You can add more complex logic based on your requirements.
            
            // For now, let's log the amount to the console
            console.log('Amount added:', amount);
        }
    </script>
</body>
</html>
