<?php
// Include your database connection file
include('db_conn.php');

// Simulate bus incharge authentication (you can replace this with your authentication logic)
$incharge_id = 1; // Assuming the incharge is logged in with ID 1

// Fetch the bus allocated to the authenticated incharge
$bus_query = "SELECT buses.bus_id, buses.bus_name
              FROM buses
              INNER JOIN bus_incharge_bus_relationship ON buses.bus_id = bus_incharge_bus_relationship.bus_id
              WHERE bus_incharge_bus_relationship.incharge_id = $incharge_id";

$bus_result = mysqli_query($db_conn, $bus_query);

if (mysqli_num_rows($bus_result) > 0) {
    $bus_row = mysqli_fetch_assoc($bus_result);
    $selected_bus_id = $bus_row['bus_id'];
    $bus_name = $bus_row['bus_name'];

    // Fetch the list of students boarding the bus allocated to the incharge
    $students_query = "SELECT students.id, students.student_name, students.blood_group, students.contact_number, students.address
                     FROM students
                     INNER JOIN student_bus_relationship ON students.id = student_bus_relationship.student_id
                     WHERE student_bus_relationship.bus_id = $selected_bus_id";

    $students_result = mysqli_query($db_conn, $students_query);

    echo "<h1>Students Boarding $bus_name</h1>";

    if (mysqli_num_rows($students_result) > 0) {
        echo "<table>";
        echo "<tr><th>ID</th><th>Student Name</th><th>Blood Group</th><th>Contact Number</th><th>Address</th></tr>";
        while ($student_row = mysqli_fetch_assoc($students_result)) {
            echo "<tr>";
            echo "<td>" . $student_row['id'] . "</td>";
            echo "<td>" . $student_row['student_name'] . "</td>";
            echo "<td>" . $student_row['blood_group'] . "</td>";
            echo "<td>" . $student_row['contact_number'] . "</td>";
            echo "<td>" . $student_row['address'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No students are boarding this bus.</p>";
    }
} else {
    echo "<p>No bus allocated to this incharge.</p>";
}

// Close the database connection
mysqli_close($db_conn);
?>

