<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transportzz Dashboard</title>
    <style>
        body {
            background-image: url('background.jpeg');
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px;
        }
        .dashboard-item {
            background-color: white;
            border-radius: 5px;
            padding: 5px;
            margin: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            min-width: 95%;
        }
        .dashboard-item img {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        }
        .dropdown {
            float: left;
            overflow: hidden;
        }
        
        .dropdown .dropbtn {
            font-size: 16px;  
            border: none;
            outline: none;
            color: #6a06a9;
            background-color: inherit;
            margin: 0;
            
            cursor: pointer;
        }
        
        .navbar a:hover, .dropdown:hover .dropbtn {
            color: black;
        }
        
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        }
        
        .dropdown-content a {
            float: none;
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            text-align: left;
        }
        
        .dropdown-content a:hover {
            background-color: #ddd;
        }
        
        .dropdown:hover .dropdown-content {
            display: block;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
            <li><a href="inchargeHomePage.php" style="text-decoration: none">Home</a></li>
            <li><a href="receivenotification.php" style="text-decoration: none">Notification</a></li>
            <li><a href="feedback.php" style="text-decoration: none">Feedback</a></li>
            <li><a href="profile1.php" style="text-decoration: none">Profile</a></li>
            <li><a href="changepassword.php" style="text-decoration: none">change password</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
        </ul>
    </div>
    <div class="dashboard">
    <!--     <div class="dashboard-item">
            <img src="trackbus.png" alt="track bus">
            <p><a href="tracklocation2.php" style="text-decoration: none">Track Bus</a></p>
        </div>
         <div class="dashboard-item">
            <img src="attendance.png" alt="attendance report">
            <p><a href="at.php" style="text-decoration: none">Attendance Report</a></p>
        </div> -->
        <div class="dashboard-item">
            <img src="student.png" alt="Student Details">
            <p><a href="samp2.php" style="text-decoration: none">Student Details</a></p>
        </div>
        <div class="dashboard-item">
            <img src="faculty.jpg" alt="Faculty Details">
            <p><a href="samp1.php" style="text-decoration: none">Faculty Details</a></p>
        </div>
        

    </div>
</body>
</html>