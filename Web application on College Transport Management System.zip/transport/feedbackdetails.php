<?php
session_start();

// Include the database connection file
include 'db_conn.php';
// Get user input from the form
$userId = $_SESSION['user_id'];
$feedbackType = $_POST['feedbackType'];
$description = $_POST['description'];


// Insert user data into the database
$sql = "INSERT INTO feedback (user_id,feedbackType,description) 
        VALUES ('$userId', '$feedbackType', '$description')";

if ($conn->query($sql) === TRUE) {
    // Signup successful, redirect to the login page
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Feedack submitted successfully')
    window.location.href='adminHomePage.php';
    </SCRIPT>");
    
    exit; // Make sure to exit to prevent further script execution
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>