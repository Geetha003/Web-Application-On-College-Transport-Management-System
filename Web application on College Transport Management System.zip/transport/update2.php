<?php
// Include your database connection file
include 'db_conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $requestId = $_POST['request_id'];

    // Update the database based on the action
    if ($action === 'accept') {
        // Perform the "Accept" action, e.g., update the status in your database
        $sql = "UPDATE bus_requests SET status = 'Accepted' WHERE id = '$requestId'";
    } elseif ($action === 'reject') {
        // Perform the "Reject" action, e.g., update the status in your database
        $sql = "UPDATE bus_requests SET status = 'Rejected' WHERE id = '$requestId'";
    }

    if ($conn->query($sql) === TRUE) {
        // Successfully updated the database
        echo 'Success';
    } else {
        // Handle any errors here
        echo 'Error updating the database: ' . $conn->error;
    }

    // Close the database connection
    $conn->close();
}

// Redirect back to the page with the table after database update
header('Location: adminHomePage.php');
?>
