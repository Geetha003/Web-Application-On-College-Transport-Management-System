<?php
// Include the database connection file
include 'db_conn.php';
// Assuming you have a database connection established
session_start();
// Fetch blood group and contact number based on the user_id
$userId = $_SESSION['user_id']; // Assuming you have stored the user_id in a session variable

$query = "SELECT blood_group, contact_no FROM transporter_signup WHERE user_Id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $userId);
$stmt->execute();
$stmt->bind_result($bloodGroup, $contactNumber);
$stmt->fetch();
$stmt->close();
// Fetch boarding point based on the user_id
// Assuming you have the user_id in a session variable
$userId = $_SESSION['user_id'];

// Fetch bus_id from bus_requests
$query = "SELECT busId FROM bus_requests WHERE student_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $userId);
$stmt->execute();
$stmt->bind_result($busId);
$stmt->fetch();
$stmt->close();

// Fetch boarding point (route) based on the bus_id
$query = "SELECT routes FROM bus_details WHERE bus_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $busId);
$stmt->execute();
$stmt->bind_result($boardingPoint);
$stmt->fetch();
$stmt->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transportzz Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
            margin-bottom:20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px;
        }
        .container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3); /* Box shadow added */
            border-radius: 10px; /* Rounded corners for the box */
            width:25%;
            margin-left:550px;
            background:white;
        }

        /* Style for the left side (details) */
        .left-side {
            flex: 1;
            padding: 5px;
        }

        /* Style for the right side (profile image) */
        .right-side {
            flex: 1;
            padding: 5px;
            text-align: center;
        }

        /* Style for the image */
        .profile-image {
            max-width: 40%;
            height: auto;
            border-radius: 100%;
            margin-right:200px;
        }  
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px;
        }
        .dashboard-item {
            background-color: white;
            border-radius: 10px;
            padding: 15px;
            margin: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            min-width: 80%;
        }
        .dashboard-item img {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        } 

 

    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
            <li><a href="studentHomePage.php" style="text-decoration: none">Home</a></li>
            <li><a href="" style="text-decoration: none">Payment</a></li>
       
            <li><a href="notification.php" style="text-decoration: none">Notification</a></li>
            <li><a href="feedback.php" style="text-decoration: none">Feedback</a></li>
            <li><a href="profile.html" style="text-decoration: none">Profile</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
        </ul>
    </div>
    <div class="container">
        <!-- Left side with profile details -->
        <div class="left-side">
            <ul>
                <li><strong>Boarding Point:</strong><?php echo htmlspecialchars($boardingPoint); ?></li>
                <li><strong>Blood Group:</strong><?php echo htmlspecialchars($bloodGroup); ?></li>
                <li><strong>Contact Number:</strong><?php echo htmlspecialchars($contactNumber); ?></li>
                <li><strong>Valid Up To:</strong>2-3-23</li>
            </ul>
        </div>
        
        <!-- Right side with the profile image -->
        <div class="right-side">
            <img class="profile-image" src="student.png" alt="Profile Image">
        </div>
    </div>
    <div class="dashboard">
        <div class="dashboard-item">
            <img src="trackbus.png" alt="track bus">
            <p><a href="" style="text-decoration: none">Track Bus</a></p>
        </div>
        <div class="dashboard-item">
            <img src="attcalendar.png" alt="attendance report">
            <p><a href="" style="text-decoration: none">Attendance Calender</a></p>
        </div>
        <div class="dashboard-item">
            <img src="requestbus.jpg" alt="request bus">
            <p><a href="bus_search.php" style="text-decoration: none">Request Bus</a></p>
        </div>
    </div>
</body>
</html>
