<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Tracking</title>
    <script src="https://api.mapbox.com/mapbox-gl-js/v2.6.1/mapbox-gl.js"></script>
    <link href="https://api.mapbox.com/mapbox-gl-js/v2.6.1/mapbox-gl.css" rel="stylesheet">
    <style>
        /* Add your CSS styles here */
        body { margin: 0; padding: 0; }
        #map { height: 100vh; }
    </style>
</head>
<body>
    <div id="map"></div>

    <script>
        mapboxgl.accessToken = 'sk.eyJ1IjoiZ2VldGhhLTEyMyIsImEiOiJjbG40NzUzM3EwMnJqMmpxaHFzNnA3aDRmIn0.8QYd2fLfAC1clBjs5FqSlQ';

        const map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/streets-v11', // You can choose a different map style
            center: [-74.006, 40.7128], // Initial map center (New York City coordinates)
            zoom: 12, // Initial zoom level
        });

        const busMarker = new mapboxgl.Marker()
            .setLngLat([-74.006, 40.7128]) // Bus initial location (New York City coordinates)
            .addTo(map);

        // Update bus location (you can replace this with real-time data)
        function updateBusLocation() {
            // Simulated bus movement (replace with actual data)
            const randomLat = 40.7128 + (Math.random() - 0.5) * 0.01;
            const randomLng = -74.006 + (Math.random() - 0.5) * 0.01;
            busMarker.setLngLat([randomLng, randomLat]);

            // Request bus location updates periodically
            setTimeout(updateBusLocation, 5000); // Update every 5 seconds
        }

        // Start updating the bus location
        updateBusLocation();
    </script>
</body>
</html>
