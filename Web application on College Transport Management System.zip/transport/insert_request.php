<?php
// Include the database connection
include 'db_conn.php';

if (isset($_POST['user_id'], $_POST['bus_id'], $_POST['status'])) {
    // Get the data from the form
    $user_id = $_POST['user_id'];
    $bus_id = $_POST['bus_id'];
    $status = $_POST['status'];

    // Check if the user already exists
    $check_sql = "SELECT * FROM bus_requests WHERE student_id = ? AND status='Accepted'";
    $check_stmt = $conn->prepare($check_sql);

    if (!$check_stmt) {
        die("SQL query error: " . $conn->error);
    }

    $check_stmt->bind_param("s", $user_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        // If the user exists, check the date
        $existing_record = $check_result->fetch_assoc();
        $existing_date = $existing_record['date'];

        // Calculate the difference between the existing date and the current date in days
        $date_diff = floor((strtotime(date("Y-m-d")) - strtotime($existing_date)) / (60 * 60 * 24));

        if ($date_diff >= 365) {  // If the difference is greater than or equal to one year (365 days)
            // Update the record with new bus ID, current date, and status as "pending"
            $update_sql = "UPDATE bus_requests SET busId = ?, date = CURDATE(), status = 'pending' WHERE student_id = ?";
            $update_stmt = $conn->prepare($update_sql);

            if (!$update_stmt) {
                die("SQL query error: " . $conn->error);
            }

            $update_stmt->bind_param("ss", $bus_id, $user_id);

            if ($update_stmt->execute()) {
                // Redirect back to the bus_search1.php page with a success query parameter
                header("Location: studentHomePage.php?success=1");
                exit();
            } else {
                echo "Error updating record: " . $update_stmt->error;
            }

            $update_stmt->close();
        } else {
            // If the difference is less than one year, do nothing or handle as needed
            echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('User has an existing request')
            window.location.href='bus_search.php';
            </SCRIPT>");
            
        }
    } else {
        // If the user does not exist, insert a new record
        $insert_sql = "INSERT INTO bus_requests (student_id, busId, status, date) VALUES (?, ?, ?, CURDATE())";
        $insert_stmt = $conn->prepare($insert_sql);

        if (!$insert_stmt) {
            die("SQL query error: " . $conn->error);
        }

        $insert_stmt->bind_param("sss", $user_id, $bus_id, $status);

        if ($insert_stmt->execute()) {
            // Redirect back to the bus_search1.php page with a success query parameter
            header("Location: studentHomePage.php?success=1");
            exit();
        } else {
            echo "Error inserting record: " . $insert_stmt->error;
        }

        $insert_stmt->close();
    }

    $check_stmt->close();
    $conn->close();
}
?>
