<?php
require_once('db_conn.php');
session_start(); // Start a session

$email = $_POST['userId'];
$pass = $_POST['pass'];

$sql = "SELECT * FROM `transporter_signup` WHERE user_Id = '$email' AND password = '$pass'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {
    // User is successfully logged in
    $row = mysqli_fetch_assoc($result);

    $user_id = $row['user_Id']; // Extract user_id from the result

    // Store user_id in a session variable
    $_SESSION['user_id'] = $user_id;
    $did = $row['DId']; // Extract the 'did' value from the result

    // Store the 'did' value in a session variable
    $_SESSION['did'] = $did;

    // Check if 'did' is 4 before redirecting
    if ($did == 3) {
        // Define redirection URLs based on 'did' value
        $redirection_urls = [
            1 => "adminHomePage.php",     // 'did' is 1, navigate to adminHomePage.php
            2 => "inchargeHomePage.php",  // 'did' is 2, navigate to inchargeHomePage.php
            4 => "studentHomePage.php",   // 'did' is 3, navigate to studentHomePage.php
            3 => "daystuHomePage.php"     // 'did' is 4, navigate to daystuHomePage.php
        ];

        // Check if the 'did' value exists in the redirection_urls array
        if (isset($redirection_urls[$did])) {
            $redirect_url = $redirection_urls[$did];
            header("Location: " . $redirect_url);
            exit();
        } else {
            // Handle cases where the 'did' value is not recognized
            echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('Invalid designation ID.')
            window.location.href='javascript:history.go(-1)';
            </SCRIPT>");
        }
    } else {
        // Handle cases where 'did' is not 4
      
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Invalid designation ID.')
        window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
    }
} else {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Invalid Email or Password')
        window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}
?>
