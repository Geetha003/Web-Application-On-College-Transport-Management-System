<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Pass</title>
    <style>
        /* Style for the rectangle container */
        .rectangle-container {
            background-color: blue; /* Background color set to blue */
            color: white; /* Text color set to white */
            padding: 10px 20px; /* Padding for the content */
            border-radius: 5px; /* Rounded corners for the rectangle */
            display: inline-block; /* Inline-block to contain the text */
            width:35%;
            text-align:center;
            margin-left:550px;
        }
    </style>
</head>
<body>
    <div class="rectangle-container">
        Bus Pass
    </div>
</body>
</html>

