<?php
// Include your database connection file
include 'db_conn.php';
session_start(); // Start the session if not already started

if (isset($_SESSION['selected_bus_id'])) {
    $bus_id = $_SESSION['selected_bus_id'];
} elseif (isset($_GET['id'])) {
    $bus_id = $_GET['id'];
} else {
    echo "Not available";
    // Handle the case when bus_id is not available.
    exit; // Terminate script execution if bus_id is not available
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transportzz Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px;
        }
        .dashboard-item {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            margin: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            min-width: 200px;
        }
        .dashboard-item img {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        }
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
            border: 1px solid #ddd;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        td{
            background-color: white;
        }
        th {
            background-color: #D9D9D9;
        }

.accept-btn, .reject-btn {
    padding: 5px 10px;
    cursor: pointer;
}

.accept-btn {
    background-color: #4CAF50;
    color: white;
    border: none;
}

.reject-btn {
    background-color: #f44336;
    color: white;
    border: none;
}
.accepted {
            color: green;
        }

        .rejected {
            color: red;
        }

    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
        <li><a href="adminHomePage.php" style="text-decoration: none">Home</a></li>
            <li><a href="profile.php" style="text-decoration: none">Profile</a></li>
            <li><a href="addbus.php" style="text-decoration: none">Add Bus</a></li>
            <li><a href="notification.php" style="text-decoration: none">Notification</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
           
        </ul>
    </div>
    <table>
    <thead>
            <tr>
                <th>ID</th>
                <th>Student Id</th>
                <th>Bus Id</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $sql = "SELECT * FROM bus_requests WHERE busId = '$bus_id' and status='pending'";
$result = $conn->query($sql);
$counter = 1;
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo "<td>" . $counter . "</td>";
        echo '<td>' . $row['student_id'] . '</td>';
        echo '<td>' . $row['busId'] . '</td>';
     //   echo '<td class="' . strtolower($row['status']) . '">' . $row['status'] . '</td>';
        echo '<td>';
        if ($row['status'] !== 'Accepted' && $row['status'] !== 'Rejected') {
                            // Add buttons for Accept and Reject
                            echo '<form method="post" action="update3.php?id=' . $bus_id . '">';
                    echo '<input type="hidden" name="action" value="accept">';
                    echo '<input type="hidden" name="request_id" value="' . $row['id'] . '">';
                    echo '<button class="btn accept-btn" type="submit">Accept</button>';
                    echo '</form>';

                    echo '<form method="post" action="update3.php?id=' . $bus_id . '">';
                    echo '<input type="hidden" name="action" value="reject">';
                    echo '<input type="hidden" name="request_id" value="' . $row['id'] . '">';
                    echo '<button class="btn reject-btn" type="submit">Reject</button>';
                    echo '</form>';
                        }
                            echo '</td>';
        echo '</tr>';
        $counter++;
    }
} else {
    echo '<tr><td colspan="4">No matching records found</td></tr>';
}


    // Loop through the results and display the data with approve and reject buttons
    

// Close the database connection
$conn->close();
?>
   </tbody>
    </table>
</body>
</html>
