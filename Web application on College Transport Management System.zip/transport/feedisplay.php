<?php
// Include your database connection file
include 'db_conn.php';
session_start();

// Fetch the user_id from the session (assuming you have stored it during login)
$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Transportzz Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
            margin-bottom:20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        table {
            border-collapse: collapse;
            width: 97%;
            margin: 20px auto;
            border: 1px solid #ddd;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        td{
            background-color: white;
        }
        th {
            background-color: #D9D9D9
        }
        .paid {
            
            color:  #4CAF50;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Style for the dropdown content */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            padding: 12px 16px;
            display: block;
            text-align: left;
        }

        /* Style for the dropdown items on hover */
        .dropdown-content a:hover {
            background-color: #ddd;
        }

        /* Show the dropdown content when hovering over the dropdown container */
        .dropdown:hover .dropdown-content {
            display: block;
        }
 

    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
        <li><a href="adminHomePage.php" style="text-decoration: none">Home</a></li>
            <li><a href="profile.php" style="text-decoration: none">Profile</a></li>
            <li><a href="addbus.php" style="text-decoration: none">Add Bus</a></li>
            <li><a href="notification.php" style="text-decoration: none">Notification</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
        </ul>
    </div>
    <h2 style="text-align: center;">Feedback</h2>
    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>User Id</th>
                <th>Feedback Type</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM feedback ";
            $result = $conn->query($sql);
            $counter = 1;
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    
                    echo "<tr>";
                    echo "<td>" . $counter . "</td>";
                    echo "<td>" . $row["user_id"] . "</td>";
                    echo "<td>" . $row["feedbackType"] . "</td>";
                    echo "<td>" . $row["description"] . "</td>";
                    
                    echo "</tr>";
                    $counter++;
                }
            } else {
                echo "<tr><td colspan='3'>No requests found</td></tr>";
            }
            ?>
        </tbody>
    </table>

</body>
</html>