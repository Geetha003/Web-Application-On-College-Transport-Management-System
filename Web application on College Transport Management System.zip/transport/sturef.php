
<!DOCTYPE html>
<html>
<head>
    <title>Student Information</title>
    <style>
        /* Add your CSS styles here */
h1 {
    text-align: center;
}

table {
    border-collapse: collapse;
    width: 80%;
    margin: 20px auto;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 8px;
    text-align: left;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

tr:hover {
    background-color: #ddd;
}

    </style>
</head>
<body>
    <h1>Students with Matching Bus Number</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Student Name</th>
                <th>Blood Group</th>
                <th>Contact Number</th>
                <th>Address</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Replace 'your_incharge_bus_no' with the actual bus number of your incharge
            $incharge_bus_no = 'bi1234';

            // Connect to the database (replace with your database connection details)
            include 'db_conn.php';


            // Query the database to retrieve student information matching the bus number
            $query = "SELECT id, studentname, blood_group, contact_number, address FROM transporter_signup WHERE bus_no = $incharge_bus_no";
            $stmt = $db->prepare($query);
            $stmt->bind_param("s", $incharge_bus_no);
            $stmt->execute();
            $result = $stmt->get_result();

            // Display the retrieved student information
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['studentname'] . "</td>";
                echo "<td>" . $row['blood_group'] . "</td>";
                echo "<td>" . $row['contact_number'] . "</td>";
                echo "<td>" . $row['address'] . "</td>";
                echo "</tr>";
            }

            // Close the database connection
            $stmt->close();
            $db->close();
            ?>
        </tbody>
    </table>
</body>
</html>
