<?php

require_once('db_conn.php');
session_start(); // Start a session

$email = $_POST['userId'];
$pass = $_POST['pass'];

$sql = "SELECT * FROM `transporter_signup` WHERE user_Id = '$email' AND password = '$pass'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {
    // User is successfully logged in
    $row = mysqli_fetch_assoc($result);
    
    $user_id = $row['user_Id']; // Extract user_id from the result

    // Store user_id in a session variable
    $_SESSION['user_id'] = $user_id;
    $did = $row['DId']; // Extract the 'did' value from the result
    // Store the 'did' value in a session variable
    $_SESSION['did'] = $did;

    // Check if the 'did' value is 1
    if ($did == 1) {
        // Redirect to adminHomePage.php
        header("Location: adminHomePage.php");
        exit();
    } else {
        // Handle cases where the 'did' value is not 1
        echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Invalid designation ID.')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
    }
} else {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Invalid Email or Password')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}

?>
