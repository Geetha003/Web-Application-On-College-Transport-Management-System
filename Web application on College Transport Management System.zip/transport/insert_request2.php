<?php
// Include the database connection
include 'db_conn.php';

if (isset($_POST['user_id'], $_POST['bus_id'], $_POST['status'])) {
    // Get the data from the form
    $user_id = $_POST['user_id'];
    $bus_id = $_POST['bus_id'];
    $status = $_POST['status'];

    // Insert the bus request into the database
    $sql = "INSERT INTO day_request (student_id, busId, status) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("SQL query error: " . $conn->error);
    }

    
    $stmt->bind_param("sss", $user_id, $bus_id, $status);

    if ($stmt->execute()) {
        // Redirect back to the bus_search1.php page with a success query parameter
        header("Location: studentHomePage.php?success=1");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and database connection
    $stmt->close();
    $conn->close();
}
?>

