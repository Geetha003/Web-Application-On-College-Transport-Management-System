<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #FFD74A;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-container {
            background-color: white;
            border-radius: 10px solid yellow;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 33%;
            text-align: center;
        }

        .login-header {
            font-size: 30px;
            font-weight: bold;
            color: #FFC805;
            margin-bottom: 20px;
        }

        label {
            display: inline-block;
            text-align: left;
            width: 50%;
            box-sizing: border-box;
        }

        .input-field {
            width: 50%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .submit-button {
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        /* Additional styles for horizontal alignment */
        .form-element-container {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .form-element-container label {
            width: auto;
            margin-right: 10px;
        }

        .form-element-container .input-field {
            width: 70%; /* Adjust as needed */
        }
    </style>
    <title>Sign-Up page</title>
</head>
<body>

<div class="login-container">
    <div class="login-header">Sign-Up</div>
    <form method="POST" action="signupprocess.php">

        <!-- Container for Name -->
        <div class="form-element-container">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" class="input-field" required>
        </div>

        <!-- Container for Designation -->
        <div class="form-element-container">
            <label for="designation">Designation</label>
            <select id="designation" name="designation" class="input-field">
                <option value="1">Admin</option>
                <option value="2">Bus Incharge</option>
                <option value="4">Annual Passenger</option>
                <option value="3">Day Passenger</option>
            </select>
        </div>

        <!-- Container for User ID -->
        <div class="form-element-container">
            <label for="userid">User ID</label>
            <input type="text" id="userid" name="userid" class="input-field" required>
        </div>

        <!-- Container for Password -->
        <div class="form-element-container">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" class="input-field" required>
        </div>

        <!-- Container for Blood Group -->
        <div class="form-element-container">
            <label for="bloodgroup">Blood Group</label>
            <select id="bloodgroup" name="bloodgroup" class="input-field">
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
            </select>
        </div>

        <!-- Container for Contact Number -->
        <div class="form-element-container">
            <label for="contact">Contact Number</label>
            <input type="tel" id="contact" name="contact" class="input-field" required>
        </div>

        <!-- Container for Address -->
        <div class="form-element-container">
            <label for="address">Address</label>
            <textarea id="address" name="address" class="input-field" rows="1" cols="1" required></textarea>
        </div>

        <button type="submit" class="submit-button">Submit</button>
    </form>
</div>
</body>
</html>
