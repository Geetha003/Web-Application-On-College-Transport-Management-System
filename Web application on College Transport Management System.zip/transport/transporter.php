<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            flex-direction: column; /* Set flex-direction to column */
        }

        .title {
            font-size: 28px;
            margin-bottom: 40px;
        }

        .container-wrapper {
            display: flex;
            flex-direction: row; /* Set flex-direction to row for the containers */
        }

        .container {
            position: relative;
            width: 220px;
            height: 220px;
            border: 2px solid #333;
            background-color: #FFD74A;
            border-radius: 10px;
            margin-right: 40px; /* Optional: Add margin between containers */
            margin-left: 30px;
            margin-bottom: 40px;
        }

        .inner-container {
            background-color: white;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100px;
            height: 100px;
            border: 2px solid #333;
        }

        .image {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .image1 {
            width: 100%;
            height: 90%;
            object-fit: cover;
        }

        .text {
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            margin-bottom: 10px;
            font-size: 14px;
        }
    </style>
    <title>Your Web Page</title>
</head>
<body>

    <div class="title">Type of passenger!</div>
     <br>
     <br>
    <div class="container-wrapper">
        <div class="container">
            <div class="inner-container">
                <img class="image" src="daily.png" alt="Image">
            </div>
            <div class="text" style="text-align: center;">
                <a href="dailylogin.php?type=daily_passenger" style="text-decoration: none; color: black; font-size: 17px; display: inline-block;">Annual Subscriber</a>
            </div>
        </div>

        <div class="container">
            <div class="inner-container">
                <img class="image1" src="passenger.png" alt="Image">
            </div>
            <div class="text">
                <a href="businchargelogin.php?type=quick_rider" style="text-decoration: none; color: black; font-size: 16px">Daily Ride</a>
            </div>
        </div>
    </div>

</body>
</html>
