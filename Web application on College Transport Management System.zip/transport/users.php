<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            background-color: white;
        }
        .contents{
            margin-left: 80px;
        }
        #content {
            text-align: center;
            margin-bottom: 20px;
            padding-left: 20px; /* Added padding to create space in front of text */
            padding-right: 20px; /* Added padding to create space in front of text */
        }

        .buttonContainer {
            margin-top: 10px;
        }

        .roleButton {
            background-color: #FFD74A;
            color: black;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 20px;
            display: flex; /* Added to make image and text align on the same line */
            align-items: center; /* Added to vertically center the content */
            width: 150%;
            text-align: center;
        }
        .text{
            margin-left: 30px;
        }

        .buttonImage {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px; /* Added margin to separate image and text */
        }
    </style>
    <title>Your Web Page</title>
</head>
<body>

    <div id="content">
        <h1 class="contents">I am a...</h1>
        <div id="buttonContainer" class="buttonContainer">
            <button class="roleButton">
                <img class="buttonImage" src="adminn.png" alt="Admin">
                <a class="text" href="loginhtml.php" style="text-decoration: none; color: black">Admin</a>
            </button>
            <br>
            <br>
            <button class="roleButton">
                <img class="buttonImage" src="businchargeee.png" alt="Transporter">
                <a class="text" href="loginn.php?type=bus_incharge" style="text-decoration: none; color: black">Bus Incharge</a>
            </button>
            <br>
            <br>
            <button class="roleButton">
                <img class="buttonImage" src="passenger.png" alt="Bus Incharge">
                <a class="text" href="transporter.php" style="text-decoration: none; color: black">Passenger</a>
            </button>
        </div>
    </div>

</body>
</html>
