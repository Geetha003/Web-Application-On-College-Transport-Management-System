<?php
// Include your database connection file
include 'db_conn.php';
session_start(); // Start the session if not already started

if (isset($_SESSION['selected_bus_id'])) {
    $bus_id = $_SESSION['selected_bus_id'];
} elseif (isset($_GET['id'])) {
    $bus_id = $_GET['id'];
} else {
    echo "Not available";
    // Handle the case when bus_id is not available.
}


// Query to retrieve student data based on bus_id
$sql = "SELECT br.student_id, ts.user_id, ts.Name
FROM bus_requests br
JOIN transporter_signup ts ON br.student_id = ts.user_id
WHERE br.bus_id = '$bus_id'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output table headers
    echo '<table>';
    echo '<thead>';
    echo '<tr>';
    echo '<th>Student ID</th>';
    echo '<th>Student Name</th>';
    echo '<th>Bus Route</th>';
    echo '<th>Status</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';

    // Loop through the results and display the data with approve and reject buttons
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['user_id'] . '</td>';
        echo '<td>' . $row['Name'] . '</td>';
        echo '<td>' . $row['bus_route'] . '</td>';
        echo '<td>';
        echo '<form method="post" action="process_approval.php">';
        echo '<input type="hidden" name="student_id" value="' . $row['user_id'] . '">';
        echo '<button class="approve-btn" type="submit" name="action" value="approve">Approve</button>';
        echo '<button class="reject-btn" type="submit" name="action" value="reject">Reject</button>';
        echo '</form>';
        echo '</td>';
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
} else {
    echo 'No matching student records found.';
}

// Close the database connection
$conn->close();
?>
