<?php
// Include the database connection file
include 'db_conn.php';
?>
<?php
$sql = "SELECT * FROM transporter_signup WHERE user_Id LIKE 'bi%'";
$result = $conn->query($sql);
$counter = 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>faculty details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px;
        }
        .dashboard-item {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            margin: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            min-width: 200px;
        }
        .dashboard-item img {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        }
        table {
            border-collapse: collapse;
            width: 97%;
            margin: 20px auto;
            border: 1px solid #ddd;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        td{
            background-color: white;
        }
        th {
            background-color: #D9D9D9;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
        <li><a href="adminHomePage.php" style="text-decoration: none">Home</a></li>
            <li><a href="profile.php" style="text-decoration: none">Profile</a></li>
            <li><a href="addbus.php" style="text-decoration: none">Add Bus</a></li>
            <li><a href="notification.php" style="text-decoration: none">Notification</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
        </ul>
    </div>
    <h2 style="text-align: center;"> Bus Incharge Details </h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Blood Group</th>
                <th>Contact Number</th>
                <th>Address</th>
            </tr>
        </thead>
        <tbody>
        <?php
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $counter . "</td>";
        echo "<td>" . $row["Name"] . "</td>";
        echo "<td>" . $row["blood_group"] . "</td>";
        echo "<td>" . $row["contact_no"] . "</td>";
        echo "<td>" . $row["Address"] . "</td>";
        echo "</tr>";
        $counter++;
    }
    ?>
            <!-- Add more rows as needed -->
        </tbody>
    </table>
</body>
</html>
