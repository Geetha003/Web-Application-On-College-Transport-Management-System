<?php
// Include your database connection file
include 'db_conn.php';
session_start();

// Fetch the user_id from the session (assuming you have stored it during login)
$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Requests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
            margin-bottom:20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px;
        }
        .container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.3); /* Box shadow added */
            border-radius: 10px; /* Rounded corners for the box */
            width:25%;
            margin-left:550px;
            background:white;
        }

        /* Style for the left side (details) */
        .left-side {
            flex: 1;
            padding: 5px;
        }

        /* Style for the right side (profile image) */
        .right-side {
            flex: 1;
            padding: 5px;
            text-align: center;
        }

        /* Style for the image */
        .profile-image {
            max-width: 40%;
            height: auto;
            border-radius: 100%;
            margin-right:200px;
        }  
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px;
        }
        .dashboard-item {
            background-color: white;
            border-radius: 10px;
            padding: 15px;
            margin: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            min-width: 80%;
        }
        .dashboard-item img {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        } 
        .rectangle-container {
            background-color: blue; /* Background color set to blue */
            color: white; /* Text color set to white */
            padding: 10px 20px; /* Padding for the content */
            border-radius: 5px; /* Rounded corners for the rectangle */
            display: inline-block; /* Inline-block to contain the text */
            width:24%;
            text-align:center;
            margin-left:548px;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Style for the dropdown content */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            padding: 12px 16px;
            display: block;
            text-align: left;
        }

        /* Style for the dropdown items on hover */
        .dropdown-content a:hover {
            background-color: #ddd;
        }

        /* Show the dropdown content when hovering over the dropdown container */
        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Style for the table */
        table {
            width: 97%;
            margin: 20px auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        th, td {
            text-align: center;
            padding: 10px;
        }

        th {
            background-color: #D9D9D9;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        /* Style for the buttons */
        .btn {
            padding: 5px 10px;
            cursor: pointer;
        }

        .accept-btn {
            background-color: #28a745;
            color: white;
        }

        .reject-btn {
            background-color: #dc3545;
            color: white;
            margin-left:7px;
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Style for the dropdown content */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            padding: 12px 16px;
            display: block;
            text-align: left;
        }

        /* Style for the dropdown items on hover */
        .dropdown-content a:hover {
            background-color: #ddd;
        }

        /* Show the dropdown content when hovering over the dropdown container */
        .dropdown:hover .dropdown-content {
            display: block;
        }
 
    </style>
</head>
<body>
<div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
        <li><a href="studentHomePage.php" style="text-decoration: none">Home</a></li>
            <!-- <li class="dropdown">
                <span style="color:#6C06BC">Payment</span>
                <div class="dropdown-content">
                    <a href="payment1.php" style="text-decoration: none">Single Pay</a>
                    <a href="payment.php" style="text-decoration: none">Annual Pay</a>
                </div>
            </li> -->
            <li> <a href="payment.php" style="text-decoration: none">Annual Pay</a></li>
            <li><a href="notification1.php" style="text-decoration: none">Notification</a></li>
            <li><a href="feedback1.php" style="text-decoration: none">Feedback</a></li>
            <li><a href="profile2.php" style="text-decoration: none">Profile</a></li>
            <li><a href="changepassword1.php" style="text-decoration: none">change password</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
        </ul>
    </div>

    <!-- Table for Student Requests -->
    <table>
    <tbody>
        <?php
// Include your database connection file

$currentDate = date('Y-m-d');
// Query to retrieve data from day_request table based on user_id
$sql_day_request = "SELECT * FROM day_request WHERE student_id = '$user_id' AND date = '$currentDate'";
$result_day_request = $conn->query($sql_day_request);

// Query to retrieve data from bus_requests table based on user_id
$sql_bus_requests = "SELECT * FROM bus_requests WHERE student_id = '$user_id'";
$result_bus_requests = $conn->query($sql_bus_requests);

// Check if there are matching records in day_request table
// if ($result_day_request->num_rows > 0) {
//     // Output table headers for day_request
//     echo '<h3 style="text-align:center">Single-Day Request</h3>';
//     echo '<table>';
//     echo '<thead>';
//     echo '<tr>';
//     echo '<th>Student ID</th>';
//     echo '<th>Bus ID</th>';
//     echo '<th>Status</th>';
//     echo '<th>Date</th>';
//     echo '</tr>';
//     echo '</thead>';
//     echo '<tbody>';

//     // Loop through the results and display the data for day_request
//     while ($row = $result_day_request->fetch_assoc()) {
//         echo '<tr>';
//         echo '<td>' . $row['student_id'] . '</td>';
//         echo '<td>' . $row['busId'] . '</td>';
//         echo '<td >' . $row['status'] . '</td>';
//         echo '<td >' . $row['date'] . '</td>';
//         echo '</tr>';
//     }

//     echo '</tbody>';
//     echo '</table>';
// } else {
//     echo 'No matching records found in the Day Request table.';
// }

// Check if there are matching records in bus_requests table
if ($result_bus_requests->num_rows > 0) {
    // Output table headers for bus_requests
    echo '<h3 style="text-align:center">Annual Bus Request</h3>';
    echo '<table>';
    echo '<thead>';
    echo '<tr>';
    echo '<th>Student Id</th>';
    echo '<th>Bus Id</th>';
    echo '<th>Status</th>';
    echo '<th>Date</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';

    // Loop through the results and display the data for bus_requests
    while ($row = $result_bus_requests->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['student_id'] . '</td>';
        echo '<td>' . $row['busId'] . '</td>';
        echo '<td >' . $row['status'] . '</td>';
        echo '<td >' . $row['date'] . '</td>';
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
} else {
    echo 'No matching records found in the Bus Requests table.';
}

// Close the database connection
$conn->close();
?>

        </tbody>
    </table>
</body>
</html>
