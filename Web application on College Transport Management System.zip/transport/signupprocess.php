<?php

require_once('db_conn.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $designation = $_POST['designation'];
    $userId = $_POST['userid'];
    $password = $_POST['password'];
    $bloodGroup = $_POST['bloodgroup'];
    $contact = $_POST['contact'];
    $address = $_POST['address'];

    // Check if the user ID already exists
    $checkExistingSQL = "SELECT * FROM `transporter_signup` WHERE user_Id = '$userId'";
    $existingResult = mysqli_query($conn, $checkExistingSQL);

    if (mysqli_num_rows($existingResult) > 0) {
        // User ID already exists
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('User ID already exists. Please choose a different User ID.')
        window.location.href='javascript:history.go(-1)';
        </SCRIPT>");
    } else {
        // User ID is unique, proceed with insertion
        $insertSQL = "INSERT INTO `transporter_signup` (Name, DId, user_Id, password, blood_group, contact_no, Address) 
                      VALUES ('$name', '$designation', '$userId', '$password', '$bloodGroup', '$contact', '$address')";
        
        $insertResult = mysqli_query($conn, $insertSQL);

        if ($insertResult) {
            // User is successfully inserted
            // Handle success as needed
            echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('User registered successfully.')
            window.location.href='loginhtml.php';
            </SCRIPT>");
        } else {
            // Handle insertion error
            echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('Error registering user. Please try again later.')
            window.location.href='javascript:history.go(-1)';
            </SCRIPT>");
        }
    }
} else {
    // Redirect to the form page if accessed directly without a POST request
    header("Location: your_form_page.php");
    exit();
}

?>
