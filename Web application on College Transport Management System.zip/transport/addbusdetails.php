<?php
// Include the database connection file
include 'db_conn.php';

// Get user input from the form

$bus_id = $_POST['BusId'];
$route = $_POST['Busroute'];
$total = $_POST['total_seats'];
$available = $_POST['available_seats'];
$occupied = $_POST['occupied_seats'];
$drivername = $_POST['drivername'];
$mob_no = $_POST['mob_no'];
$incharge_id = $_POST['inchargeId'];
$inchargename = $_POST['inchargename'];
$mobile_no = $_POST['mobile_no'];


// Insert user data into the database
$sql = "INSERT INTO bus_details (bus_id,routes,total_seats,available_seats,occupied_seats,
driver_name,driver_contact,busInChargeID) 
        VALUES ('$bus_id', '$route','$total','$available','$occupied','$drivername', '$mob_no','$incharge_id')";

if ($conn->query($sql) === TRUE) {
    // Signup successful, redirect to the login page
    header('Location: adminHomePage.php');
    exit; // Make sure to exit to prevent further script execution
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>

