<!DOCTYPE html>
<html>
<head>
    <title>Student Requests</title>
    <style>
        body {
            background-image: url('background.jpeg');
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
        }

        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }

        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .nav-links li {
            cursor: pointer;
        }

        /* Style for the table */
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        th, td {
            text-align: center;
            padding: 10px;
        }

        th {
            background-color: #D9D9D9;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        /* Style for the buttons */
        .btn {
            padding: 5px 10px;
            cursor: pointer;
        }

        .accept-btn {
            background-color: #28a745;
            color: white;
        }

        .reject-btn {
            background-color: #dc3545;
            color: white;
            margin-left:7px;
        }
        /* Your existing CSS styles here */

        /* Add these CSS styles to your existing <style> section */
        .accepted {
            color: green;
        }

        .rejected {
            color: red;
        }
    </style>
</head>
<body>
<div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
            <li><a href="inchargeHomePage.php" style="text-decoration: none">Home</a></li>
            <li><a href="receivenotification.php" style="text-decoration: none">Notification</a></li>
            <li><a href="feedback.php" style="text-decoration: none">Feedback</a></li>
            <li><a href="profile.html" style="text-decoration: none">Profile</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
        </ul>
    </div>
        <!-- Your navigation menu here -->
    </div>

    <!-- Table for Student Requests -->
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Student Name</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Include your database connection file
            include 'db_conn.php';
            session_start();

            $user_id = $_SESSION['user_id'];

            // Query to fetch busId based on user_id from bus-details table
            $sql_get_bus_id = "SELECT bus_id FROM bus_details WHERE busInChargeID = '$user_id'";
            $result_get_bus_id = $conn->query($sql_get_bus_id);

            if ($result_get_bus_id->num_rows > 0) {
                $row_bus = $result_get_bus_id->fetch_assoc();
                $bus_id = $row_bus['bus_id'];

                // Query to fetch matching rows from day_request table based on bus_id
                $sql = "SELECT id, student_id, status FROM day_request WHERE busId = '$bus_id'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $student_id = $row['student_id'];

                        // Query to fetch student name based on student_id
                        $sql_student_name = "SELECT Name FROM transporter_signup WHERE user_Id = '$student_id'";
                        $result_student_name = $conn->query($sql_student_name);

                        if ($result_student_name->num_rows > 0) {
                            $row_student_name = $result_student_name->fetch_assoc();
                            $student_name = $row_student_name['Name'];

                            echo '<tr>';
                            echo '<td>' . $row['id'] . '</td>';
                            echo '<td>' . $student_name . '</td>';
                            echo '<td class="' . strtolower($row['status']) . '">' . $row['status'] . '</td>';
                            echo '<td>';

                            // Conditionally display buttons based on status
                            if ($row['status'] !== 'Accepted' && $row['status'] !== 'Rejected') {
                                echo '<form method="post" action="update.php">';
                                echo '<input type="hidden" name="action" value="accept">';
                                echo '<input type="hidden" name="request_id" value="' . $row['id'] . '">';
                                echo '<button class="btn accept-btn" type="submit">Accept</button>';
                                echo '</form>';

                                echo '<form method="post" action="update.php">';
                                echo '<input type="hidden" name="action" value="reject">';
                                echo '<input type="hidden" name="request_id" value="' . $row['id'] . '">';
                                echo '<button class="btn reject-btn" type="submit">Reject</button>';
                                echo '</form>';
                            }

                            echo '</td>';
                            echo '</tr>';
                        }
                    }
                } else {
                    echo '<tr><td colspan="3">No matching student requests found</td></tr>';
                }
            } else {
                echo '<tr><td colspan="3">No bus information found for this user</td></tr>';
            }

            // Close the database connection
            $conn->close();
            ?>
        </tbody>
    </table>
</body>
</html>
