<?php
require 'db_conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_name = $_POST['student_name'];
    $status = 0; // Pending

    $stmt = $conn->prepare("INSERT INTO bus_requests (student_name, status) VALUES (?, ?)");
    $stmt->execute([$student_name, $status]);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Portal</title>
</head>
<body>
    <h1>Student Portal</h1>
    <form method="POST" action="student.php">
        <label for="student_name">Student Name:</label>
        <input type="text" name="student_name" required>
        <button type="submit">Submit Request</button>
    </form>
</body>
</html>
