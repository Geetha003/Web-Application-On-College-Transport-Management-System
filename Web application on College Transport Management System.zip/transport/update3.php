<?php
include 'db_conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $request_id = $_POST['request_id'];

    if ($action === 'accept') {
        // Update the status of the request to 'Accepted' in the bus_requests table
        $sqlUpdateRequest = "UPDATE bus_requests SET status = 'Accepted' WHERE id = '$request_id'";
        $conn->query($sqlUpdateRequest);

        // Retrieve the associated busId from the accepted request
        $sqlGetBusId = "SELECT busId FROM bus_requests WHERE id = '$request_id'";
        $result = $conn->query($sqlGetBusId);

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $busId = $row['busId'];

            // Update the bus_details table to decrement available seats and increment occupied seats
            $sqlUpdateBusDetails = "UPDATE bus_details SET available_seats = available_seats - 1, occupied_seats = occupied_seats + 1 WHERE bus_id = '$busId'";
            $conn->query($sqlUpdateBusDetails);
        }
    } elseif ($action === 'reject') {
        // Update the status of the request to 'Rejected' in the bus_requests table
        $sqlUpdateRequest = "UPDATE bus_requests SET status = 'Rejected' WHERE id = '$request_id'";
        $conn->query($sqlUpdateRequest);
    }
}

// Redirect back to the page where the request list is displayed
header("Location: checkavailable.php");
exit;
?>
