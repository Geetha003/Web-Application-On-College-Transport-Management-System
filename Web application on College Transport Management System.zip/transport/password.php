<?php
// Include the database connection file
include 'db_conn.php';
session_start();
// Get user input from the form
$user_id = $_SESSION['user_id']; // Assuming you store user_id in session after login
$old_password = $_POST['oldPassword'];
$new_password = $_POST['newPassword'];
$confirm_password = $_POST['confirmPassword'];

// Check if the old password matches the password in the transporter_signup table
$check_sql = "SELECT * FROM `transporter_signup` WHERE user_Id = ? AND password = ?";
$check_stmt = $conn->prepare($check_sql);

if (!$check_stmt) {
    die("SQL query error: " . $conn->error);
}

$check_stmt->bind_param("ss", $user_id, $old_password);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows == 1) {
    // Old password is a match, check if new password and confirm password match
    if ($new_password === $confirm_password) {
        // Update the password in the transporter_signup table
        $update_sql = "UPDATE `transporter_signup` SET password = ? WHERE user_Id = ?";
        $update_stmt = $conn->prepare($update_sql);

        if (!$update_stmt) {
            die("SQL query error: " . $conn->error);
        }

        $update_stmt->bind_param("ss", $new_password, $user_id);

        if ($update_stmt->execute()) {
            // Password updated successfully
            echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('Updated Successfully ')
            window.location.href='javascript:history.go(-1)';
            </SCRIPT>");
           // Make sure to exit to prevent further script execution
        } else {
            echo "Error updating password: " . $conn->error;
        }

        $update_stmt->close();
    } else {
        echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('Error: New password and confirm password do not match. ')
            window.location.href='javascript:history.go(-1)';
            </SCRIPT>");
    
    }
} else {
    // Old password does not match
    echo ("<SCRIPT LANGUAGE='JavaScript'>
            window.alert('Error: Old password does not match. ')
            window.location.href='javascript:history.go(-1)';
            </SCRIPT>");
  
}

$check_stmt->close();
$conn->close();
?>
