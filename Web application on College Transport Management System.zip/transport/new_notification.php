<?php
// Include your database connection file
include 'db_conn.php';

// Check if the 'id' parameter is set in the URL
// Fetch all bus requests
$sql = "SELECT * FROM bus_requests WHERE status = 'Pending'";
$result = $conn->query($sql);

if ($result === false) {
    // Query execution failed
    echo "Error: " . $conn->error;
} elseif ($result->num_rows > 0) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Transportzz Dashboard</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 0;
                background-color: #f4f4f4;
            }
            .navbar {
                display: flex;
                justify-content: space-between;
                align-items: center;
                background-color: #FFC805;
                color: black;
                padding: 10px 20px;
            }
            .logo {
                display: flex;
                align-items: center;
            }
            .logo img {
                width: 40px;
                height: 40px;
                margin-right: 10px;
            }
            .nav-links {
                display: flex;
                gap: 20px;
                list-style: none;
                margin: 0;
                padding: 0;
            }
            .nav-links li {
                cursor: pointer;
            }
            .dashboard {
                display: flex;
                justify-content: center;
                align-items: center;
                flex-wrap: wrap;
                padding: 20px;
            }
            .dashboard-item {
                background-color: white;
                border-radius: 10px;
                padding: 20px;
                margin: 20px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                display: flex;
                flex-direction: column;
                align-items: center;
                text-align: center;
                min-width: 200px;
            }
            .dashboard-item img {
                width: 80px;
                height: 80px;
                margin-bottom: 10px;
            }
            .row {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                border: 1px solid #ccc;
                padding: 10px;
                margin: 10px;
                background:white;
            }

            /* Style for the left content */
            .left-content {
                flex: 1; /* Occupy half of the row */
                display: flex;
                flex-direction: column; /* Arrange items vertically */
            }

            /* Style for the right content */
            .right-content {
                display: flex;
                flex-direction: column; /* Arrange buttons vertically */
                align-items: flex-end;
            }

            .accept-btn,
            .reject-btn {
                padding: 5px 10px;
                cursor: pointer;
                margin-top: 5px; /* Added spacing between buttons */
            }

            .accept-btn {
                background-color: #4CAF50;
                color: white;
                border: none;
            }

            .reject-btn {
                background-color: #f44336;
                color: white;
                border: none;
            }
        </style>
    </head>
    <body>
        <div class="navbar">
            <div class="logo">
                <img src="buslogo.png" alt="Transportzz Logo">
                <h1>Transportzz</h1>
            </div>
            <ul class="nav-links">
                <li><a href="adminHomePage.php" style="text-decoration: none">Home</a></li>
                <li><a href="profile.php" style="text-decoration: none">Profile</a></li>
                <li><a href="addbus.php" style="text-decoration: none">Add Bus</a></li>
                <li><a href="notification.php" style="text-decoration: none">Notification</a></li>
                <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
            </ul>
        </div>
        <?php
        // Loop through each row in the result set
        while ($bus = $result->fetch_assoc()) {
            ?>
            <div class="row">
            <div class="left-content">
    <span>Student ID: <?php echo $bus["student_id"]; ?></span>
    <span>Bus ID: <?php echo $bus["busId"]; ?></span>
    
    <?php
    // Fetch available seats from bus_details table based on bus_id
    $bus_id = $bus["busId"];
    $available_seats_query = "SELECT available_seats FROM bus_details WHERE bus_id = '$bus_id'";
    $available_seats_result = $conn->query($available_seats_query);

    if ($available_seats_result->num_rows > 0) {
        $available_seats_row = $available_seats_result->fetch_assoc();
        $available_seats = $available_seats_row["available_seats"];

        echo '<span>Available Seats: ' . $available_seats . '</span>';
    } else {
        echo '<span>Available Seats: Not Available</span>';
    }
    ?>
</div>

                <div class="right-content">
                    <?php
                    if ($bus['status'] !== 'Accepted' && $bus['status'] !== 'Rejected') {
                        // Add buttons for Accept and Reject
                        echo '<form method="post" action="update3.php?id=' . $bus["busId"] . '">';
                        echo '<input type="hidden" name="action" value="accept">';
                        echo '<input type="hidden" name="request_id" value="' . $bus["id"] . '">';
                        echo '<button class="btn accept-btn" type="submit">Accept</button>';
                        echo '</form>';

                        echo '<form method="post" action="update3.php?id=' . $bus["busId"] . '">';
                        echo '<input type="hidden" name="action" value="reject">';
                        echo '<input type="hidden" name="request_id" value="' . $bus["id"] . '">';
                        echo '<button class="btn reject-btn" type="submit">Reject</button>';
                        echo '</form>';
                    }
                    ?>
                </div>
            </div>
            <?php
        }
        ?>
    </body>
    </html>
    <?php
} else {
    echo "No bus requests found.";
}

// Close the database connection (if required)
$conn->close();
?>
