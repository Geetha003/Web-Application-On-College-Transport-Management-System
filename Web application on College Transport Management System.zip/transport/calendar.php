<?php
// Include the database connection file
include 'db_conn.php';
// Assuming you have a database connection established
session_start();
// Fetch blood group and contact number based on the user_id
$userId = $_SESSION['user_id']; // Assuming you have stored the user_id in a session variable

$query = "SELECT blood_group, contact_no FROM transporter_signup WHERE user_Id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $userId);
$stmt->execute();
$stmt->bind_result($bloodGroup, $contactNumber);
$stmt->fetch();
$stmt->close();
// Fetch boarding point based on the user_id
// Assuming you have the user_id in a session variable
$userId = $_SESSION['user_id'];

// Fetch bus_id from bus_requests
$query = "SELECT busId FROM bus_requests WHERE student_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $userId);
$stmt->execute();
$stmt->bind_result($busId);
$stmt->fetch();
$stmt->close();

// Fetch boarding point (route) based on the bus_id
$query = "SELECT routes FROM bus_details WHERE bus_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $busId);
$stmt->execute();
$stmt->bind_result($boardingPoint);
$stmt->fetch();
$stmt->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transportzz Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
            margin-bottom:20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        .calendar {
            font-family: Arial, sans-serif;
            text-align: center;
        }
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            width: 30px;
        }
        th {
            background-color: #D9D9D9;
            color: black;
        }
        tr {
            background-color: white;
            color: black;
        }
        .current-day {
            background-color: #ffcccb; /* Highlight color for the current day */
        }
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Style for the dropdown content */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            padding: 12px 16px;
            display: block;
            text-align: left;
        }

        /* Style for the dropdown items on hover */
        .dropdown-content a:hover {
            background-color: #ddd;
        }

        /* Show the dropdown content when hovering over the dropdown container */
        .dropdown:hover .dropdown-content {
            display: block;
        }
 

    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
        <li><a href="studentHomePage.php" style="text-decoration: none">Home</a></li>
            <!-- <li class="dropdown">
                <span style="color:#6C06BC">Payment</span>
                <div class="dropdown-content">
                    <a href="payment1.php" style="text-decoration: none">Single Pay</a>
                    <a href="payment.php" style="text-decoration: none">Annual Pay</a>
                </div>
            </li> -->
            <li> <a href="payment.php" style="text-decoration: none">Annual Pay</a></li>
            <li><a href="notification1.php" style="text-decoration: none">Notification</a></li>
            <li><a href="feedback1.php" style="text-decoration: none">Feedback</a></li>
            <li><a href="profile2.php" style="text-decoration: none">Profile</a></li>
            <li><a href="changepassword1.php" style="text-decoration: none">change password</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
        </ul>
    </div>
    <div class="calendar">
        <h2>Calendar</h2>
        <table>
            <thead>
                <tr>
                    <th>Sun</th>
                    <th>Mon</th>
                    <th>Tue</th>
                    <th>Wed</th>
                    <th>Thu</th>
                    <th>Fri</th>
                    <th>Sat</th>
                </tr>
            </thead>
            <tbody>
                <!-- JavaScript will add calendar days here -->
            </tbody>
        </table>
    </div>

    <script>
    function createCalendar() {
        const currentDate = new Date();
        const currentMonth = currentDate.toLocaleString('default', { month: 'long' });
        const currentYear = currentDate.getFullYear();
        const currentDay = currentDate.getDate();
        const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
        const firstDayIndex = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
        const daysElement = document.querySelector('tbody');
        let dayCount = 1;

        // Set the text content of the h2 tag to display the current month and year
        document.querySelector('h2').textContent = `${currentMonth} ${currentYear}`;

        for (let i = 0; i < 6; i++) {
            const row = document.createElement('tr');
            for (let j = 0; j < 7; j++) {
                const cell = document.createElement('td');
                if ((i === 0 && j < firstDayIndex) || dayCount > daysInMonth) {
                    // Empty cell before the first day and after the last day
                    cell.textContent = '';
                } else {
                    cell.textContent = dayCount;
                    if (dayCount === currentDay) {
                        cell.classList.add('current-day');
                    }
                    dayCount++;
                }
                row.appendChild(cell);
            }
            daysElement.appendChild(row);
        }
    }

    createCalendar();
</script>
</body>
</html>