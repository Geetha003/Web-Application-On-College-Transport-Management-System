<?php
// Include the database connection
include 'db_conn.php';

if (isset($_POST['user_id'], $_POST['bus_id'], $_POST['status'])) {
    // Get the data from the form
    $user_id = $_POST['user_id'];
    $bus_id = $_POST['bus_id'];
    $status = $_POST['status'];

    // Check if a request with the same user ID, accepted status, and today's date exists
    $checkSql = "SELECT * FROM day_request WHERE student_id = ? AND status = 'Accepted' AND DATE(date) = CURDATE()";
    $checkStmt = $conn->prepare($checkSql);

    if (!$checkStmt) {
        die("SQL query error: " . $conn->error);
    }

    $checkStmt->bind_param("s", $user_id);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows > 0) {
        // Request already present for the user with accepted status and today's date
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Request already present for the user with Accepted status')
        window.location.href='bus_search2.php';
        </SCRIPT>");
       
    } else {
        // Insert the bus request into the database
        $insertSql = "INSERT INTO day_request (student_id, busId, status) VALUES (?, ?, ?)";
        $insertStmt = $conn->prepare($insertSql);

        if (!$insertStmt) {
            die("SQL query error: " . $conn->error);
        }

        $insertStmt->bind_param("sss", $user_id, $bus_id, $status);

        if ($insertStmt->execute()) {
            // Redirect back to the bus_search1.php page with a success query parameter
            header("Location: daystuHomePage.php?success=1");
            exit();
        } else {
            echo "Error: " . $insertStmt->error;
        }

        // Close the statement for the insert query
        $insertStmt->close();
    }

    // Close the statement for the check query and database connection
    $checkStmt->close();
    $conn->close();
}
?>
