<?php
// Include your database connection file
include 'db_conn.php';

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    $bus_id = $_GET['id'];

    // Fetch the bus details based on the 'id' parameter
    $sql = "SELECT * FROM bus_details WHERE bus_id = '$bus_id'";
    $result = $conn->query($sql);

    if ($result === false) {
        // Query execution failed
        echo "Error: " . $conn->error;
    } elseif ($result->num_rows > 0) {
        $bus = $result->fetch_assoc();
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transportzz Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        .dashboard {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            padding: 20px;
        }
        .dashboard-item {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            margin: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            min-width: 200px;
        }
        .dashboard-item img {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        }
        .profile-card {
            display: flex;
            align-items: center;
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

  .profile-card {
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    padding: 30px;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
  }

  .profile-header {
    display: flex;
    align-items: center;
  }

  .profile-photo {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    object-fit: cover;
    margin-right: 10px;
  }

  .profile-name {
    font-size: 20px;
    font-weight: bold;
    ;
  }

  .profile-details {
    margin-top: 20px;
    font-size: 14px;
    text-align: flex;
  }
  .driver-details {
    margin-top: 30px;
  }

  .driver-heading {
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 10px;
  }

  .driver-info {
    font-size: 14px;
  }
  .submit-button {
    background-color: #FFC805 ;
    color: black;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    width: 50%
  }

    </style>
     
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
        <li><a href="adminHomePage.php" style="text-decoration: none">Home</a></li>
            <li><a href="profile.php" style="text-decoration: none">Profile</a></li>
            <li><a href="addbus.php" style="text-decoration: none">Add Bus</a></li>
            <li><a href="notification.php" style="text-decoration: none">Notification</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
           
        </ul>
    </div>
    <div class="profile-card">
        <div class="profile-header">
          <img class="profile-photo" src="driver.png" alt="Profile Photo">
          <div class="profile-name">Bus Details</div>
        </div>
        <div class="profile-details">
            <p><strong>Bus id:</strong> <?php echo $bus["bus_id"]; ?></p>
      <p><strong>Bus Route:</strong>  <?php echo $bus["routes"]; ?></p>
      <p><strong>Total Seats:</strong>  <?php echo $bus["total_seats"]; ?></p>
      <p><strong>Available Seats:</strong>  <?php echo $bus["available_seats"]; ?></p>
      <p><strong>Occupied Seats:</strong>  <?php echo $bus["occupied_seats"]; ?></p> 
           </div>
           <div class="driver-details">
            <div class="driver-heading">Driver Details</div>
            <div class="driver-info">
              <p><strong>Name:</strong><?php echo $bus["driver_name"]; ?></p>
              <p><strong>Contact No.:</strong> <?php echo $bus["driver_contact"]; ?></p>
            </div>
          </div>
          <br>
          <!-- <button type="submit" class="submit-button">
    <a href="approvalist.php?id=<?php echo $bus_id; ?>" style="text-decoration: none">View Approval List</a>
</button> -->

        
        </div>
      </div>

</body>
</html>
<?php
    } else {
        echo "Bus not found.";
    }
} else {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Updated Successfully.')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}

// Close the database connection (if required)
$conn->close();
?>