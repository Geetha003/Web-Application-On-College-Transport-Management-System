<?php
// Include the database connection file
include 'db_conn.php';
// Assuming you have a database connection established
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transportzz Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #FFC805;
            color: black;
            padding: 10px 20px;
            margin-bottom:20px;
        }
        .logo {
            display: flex;
            align-items: center;
        }
        .logo img {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            cursor: pointer;
        }
        /* Style the form container */
form {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f9f9f9;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
}

/* Style labels */
label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

/* Style input fields */
input[type="text"] {
    width: 95%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 3px;
}

/* Style the submit button */
button[type="submit"] {
    background-color: #FFC805;
            color: black;
    border: none;
    padding: 10px 20px;
    border-radius: 3px;
    cursor: pointer;
    display:center;
}
/* Style for the search results container */
.results-container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f9f9f9;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
}

/* Style for the table */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 15px;
}

/* Style for table headers */
th {
    background-color: #007BFF;
    color: #fff;
    padding: 10px;
}

/* Style for table rows */
tr:nth-child(even) {
    background-color: #f2f2f2;
}

/* Style for table cells */
td, th {
    padding: 10px;
    text-align: left;
}

/* Style for the "No buses found" message */
.no-results {
    color: #ff0000;
    font-weight: bold;
    margin-top: 15px;
}
.dropdown {
            position: relative;
            display: inline-block;
        }

        /* Style for the dropdown content */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            padding: 12px 16px;
            display: block;
            text-align: left;
        }

        /* Style for the dropdown items on hover */
        .dropdown-content a:hover {
            background-color: #ddd;
        }

        /* Show the dropdown content when hovering over the dropdown container */
        .dropdown:hover .dropdown-content {
            display: block;
        }
 


    </style>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <img src="buslogo.png" alt="Transportzz Logo">
            <h1>Transportzz</h1>
        </div>
        <ul class="nav-links">
        <li><a href="studentHomePage.php" style="text-decoration: none">Home</a></li>
            <li class="dropdown">
                <span style="color:#6C06BC">Payment</span>
                <div class="dropdown-content">
                    <a href="payment1.php" style="text-decoration: none">Single Pay</a>
                    <a href="payment.php" style="text-decoration: none">Annual Pay</a>
                </div>
            </li>
       
            <li><a href="notification1.php" style="text-decoration: none">Notification</a></li>
            <li><a href="feedback1.php" style="text-decoration: none">Feedback</a></li>
            <li><a href="profile2.php" style="text-decoration: none">Profile</a></li>
            <li><a href="startpage.php" style="text-decoration: none">Logout</a></li>
        </ul>
    </div>
<form method="post" action="bus_search1.php">
    <label for="route_name">Enter Route Name:</label>
    <input type="text" name="route_name" id="route_name" required>
    <button type="submit" name="search_buses">Check Available</button>
</form>
<br>
<br>
<?php
// Include the database connection


// Include the user authentication code to capture user_id and user_name
// Make sure you have the user's information available in session variables

if (isset($_POST['search_buses'])) {
    // Get the user input (route_name)
    $route_name = $_POST['route_name'];
    // Capture user_id and user_name from session variables
    $user_id = $_SESSION['user_id'];
    

    // Prepare and execute the SQL query with error handling
    $sql = "SELECT * FROM bus_details WHERE routes LIKE ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("SQL query error: " . $db->error);
    }

    $search_pattern = '%' . $route_name . '%';
    $stmt->bind_param("s", $search_pattern);
    $stmt->execute();

    // Get the result set
    $result = $stmt->get_result();

    // Display the search results
    if ($result->num_rows > 0) {
        echo '<div class="results-container">';
        echo '<h2>Buses on Route: ' . htmlspecialchars($route_name) . '</h2>';
        echo '<table>';
        echo '<tr><th>Bus ID</th><th>Routes</th><th>Total Seats</th><th>Available Seats</th><th>Occupied Seats</th><th>Action</th></tr>';

        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row['bus_id']) . '</td>';
            echo '<td>' . htmlspecialchars($row['routes']) . '</td>';
            echo '<td>' . htmlspecialchars($row['total_seats']) . '</td>';
            echo '<td>' . htmlspecialchars($row['available_seats']) . '</td>';
            echo '<td>' . htmlspecialchars($row['occupied_seats']) . '</td>';
            echo '<td><form method="post" action="insert_request2.php">';
            echo '<input type="hidden" name="user_id" value="' . htmlspecialchars($user_id) . '">';
            echo '<input type="hidden" name="bus_id" value="' . htmlspecialchars($row['bus_id']) . '">';
            echo '<input type="hidden" name="status" value="pending">';
            echo '<button type="submit">Request</button>';
            echo '</form></td>';
            echo '</tr>';
            

        }

        echo '</table>';
        echo '</div>';
    } else {
        echo '<p class="no-results">No buses found on Route: ' . htmlspecialchars($route_name) . '</p>';
    }

    // Close the statement and database connection
    $stmt->close();
    $conn->close();
}
?>

</body>
</html>



